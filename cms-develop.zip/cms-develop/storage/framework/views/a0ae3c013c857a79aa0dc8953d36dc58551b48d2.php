
    <?php $__env->startSection('title','Blog'); ?>
    <?php $__env->startSection('content'); ?>
    <a href="<?php echo e(route('showjson')); ?>" title="json">teste</a>
    <form action="<?php echo e(route('store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div>
            <label for="title">Blog Title:</label><br>
            <input type="text" name="title" id="title" required>
        </div>
        <div>
            <label for="content">Content:</label><br>
            <textarea name="content" id="content" required></textarea>
        </div>        
        <button type="submit">Send</button>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\cms-develop\resources\views/blog.blade.php ENDPATH**/ ?>