
<?php $__env->startSection('title', 'Doutores cms'); ?>
<?php $__env->startSection('content'); ?>
    <a class="dash-btn" href="<?php echo e(route('blog')); ?>" title="Blog">Blog</a>
    <?php if(isset($posts)): ?>
        <ul id="lista-posts">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <strong>Titulo: <?php echo e($post->title); ?></strong><br>
                    <span>Conteúdo: <?php echo e($post->content); ?></span>
                </li>
                <img src="<?php echo e(asset('storage/' . $post->image_slug)); ?>" alt="Imagem do Blog" width="200">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>
<script>
    document.getElementById('recarregar').addEventListener('click', () => {
        fetch('/api/blogs') // você pode ter essa rota separada só pra JS
            .then(res => res.json())
            .then(data => {
                const lista = document.getElementById('lista-posts');
                lista.innerHTML = ''; // limpa a lista atual

                data.forEach(post => {
                    const li = document.createElement('li');
                    
                    lista.appendChild(li);
                });
            });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\cms-develop\resources\views/index.blade.php ENDPATH**/ ?>