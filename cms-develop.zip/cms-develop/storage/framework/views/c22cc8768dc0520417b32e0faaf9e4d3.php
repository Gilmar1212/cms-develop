
    <?php $__env->startSection('title','Blog'); ?>
    <?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('store')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div>
            <label for="title">Titulo:</label><br>
            <input type="text" name="title" id="title" required>
        </div>
        <div>
            <label for="title">Breve descrição:</label><br>
            <input type="text" name="short_description" id="short-description">
        </div>
        <div>
            <label for="content">Content:</label><br>
            <textarea name="content" id="content" required></textarea>
        </div>    
        <div>
            <label for="image">image:</label><br>
            <input type="file" name="image" id="image" accept="image/*" required>
        </div>        
        <button type="submit">Send</button>
    </form>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\cms-develop\resources\views/blog.blade.php ENDPATH**/ ?>