
<?php $__env->startSection('title', 'Doutores cms'); ?>
<?php $__env->startSection('content'); ?>
    <a href="<?php echo e(route('blog')); ?>" title="Blog">Blog</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\cms-develop\resources\views/index.blade.php ENDPATH**/ ?>