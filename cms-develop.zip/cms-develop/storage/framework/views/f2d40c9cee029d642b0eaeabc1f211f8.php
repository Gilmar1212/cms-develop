<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Doutores CMS - Sistema de gerenciamento de conteúdo.">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>
<body>
  <?php echo $__env->yieldContent('content'); ?>
</body>
</html><?php /**PATH C:\wamp64\www\cms-develop\resources\views/layouts/template.blade.php ENDPATH**/ ?>